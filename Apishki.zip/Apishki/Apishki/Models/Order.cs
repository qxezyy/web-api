﻿using System;
using System.Collections.Generic;

namespace Apishki.Models;

public partial class Order
{
    public int IdOrder { get; set; }

    public int UuserId { get; set; }

    public DateTime OrderDate { get; set; }

    public decimal Totalamount { get; set; }

    public string StatusOrder { get; set; } = null!;

    public string? DeliveryAddress { get; set; }

    public virtual ICollection<OrderItem> OrderItems { get; set; } = new List<OrderItem>();

    public virtual User Uuser { get; set; } = null!;
}
