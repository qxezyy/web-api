﻿using System;
using System.Collections.Generic;

namespace Apishki.Models;

public partial class Product
{
    public int IdProduct { get; set; }

    public string Title { get; set; } = null!;

    public decimal Price { get; set; }

    public int CategoryId { get; set; }

    public DateTime RegistrationDate { get; set; }

    public string? DescriptionProduct { get; set; }

    public string? Image { get; set; }

    public virtual ICollection<CartItem> CartItems { get; set; } = new List<CartItem>();

    public virtual Category Category { get; set; } = null!;

    public virtual ICollection<OrderItem> OrderItems { get; set; } = new List<OrderItem>();
}
