﻿using System;
using System.Collections.Generic;

namespace Apishki.Models;

public partial class OrderItem
{
    public int IdOrderitem { get; set; }

    public int OrderId { get; set; }

    public int ProductId { get; set; }

    public string Title { get; set; } = null!;

    public decimal Price { get; set; }

    public int Quantity { get; set; }

    public virtual Order Order { get; set; } = null!;

    public virtual Product Product { get; set; } = null!;
}
