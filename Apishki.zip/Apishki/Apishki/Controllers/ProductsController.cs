﻿using Apishki.DTOs.Product;
using Apishki.Models;
using Microsoft.AspNetCore.Mvc;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("api/products")]
    public class ProductsController : ControllerBase
    {
        private readonly Db33Context _context;

        public ProductsController(Db33Context context)
        {
            _context = context;
        }

        private static ProductDTO ToDto(Product p) => new ProductDTO
        {
            Id = p.IdProduct,
            Title = p.Title,
            Price = p.Price,
            CategoryId = p.CategoryId,
            Description = p.DescriptionProduct,
            Image = p.Image,
            CreatedAt = p.RegistrationDate
        };

        [HttpGet]
        public IActionResult GetAll(int page = 1, int pageSize = 10)
        {
            var products = _context.Products
                .OrderBy(p => p.IdProduct)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .AsEnumerable()
                .Select(ToDto)
                .ToList();

            return Ok(products);
        }

        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            var product = _context.Products.FirstOrDefault(p => p.IdProduct == id);
            if (product is null) return NotFound();

            return Ok(ToDto(product));
        }

        [HttpPost]
        public IActionResult Create(CreateProductDTO dto)
        {
            var product = new Product
            {
                Title = dto.Title,
                Price = dto.Price,
                CategoryId = dto.CategoryId,
                DescriptionProduct = dto.Description,
                Image = dto.Image,
                RegistrationDate = DateTime.UtcNow
            };

            _context.Products.Add(product);
            _context.SaveChanges();

            return CreatedAtAction(nameof(GetById), new { id = product.IdProduct }, ToDto(product));
        }

        [HttpPut("{id}")]
        public IActionResult Update(int id, UpdateProductDTO dto)
        {
            var product = _context.Products.FirstOrDefault(p => p.IdProduct == id);
            if (product is null) return NotFound();

            product.Title = dto.Title;
            product.Price = dto.Price;
            product.CategoryId = dto.CategoryId;
            product.DescriptionProduct = dto.Description;
            product.Image = dto.Image;

            _context.SaveChanges();
            return NoContent();
        }

        [HttpPatch("{id}")]
        public IActionResult Patch(int id, PatchProductDTO dto)
        {
            var product = _context.Products.FirstOrDefault(p => p.IdProduct == id);
            if (product is null) return NotFound();

            if (dto.Title is not null) product.Title = dto.Title;
            if (dto.Price is not null) product.Price = dto.Price.Value;
            if (dto.CategoryId is not null) product.CategoryId = dto.CategoryId.Value;
            if (dto.Description is not null) product.DescriptionProduct = dto.Description;
            if (dto.Image is not null) product.Image = dto.Image;

            _context.SaveChanges();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var product = _context.Products.FirstOrDefault(p => p.IdProduct == id);
            if (product is null) return NotFound();

            _context.Products.Remove(product);
            _context.SaveChanges();
            return NoContent();
        }
    }
}